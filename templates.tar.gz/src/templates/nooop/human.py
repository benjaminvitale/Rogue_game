def create(name, face, location):
    return {
        "name": name,
        "face": face,
        "location": location,
        "inventory": [],
        "hp": 50,
        "max_hp": 50
    }


def has_sword(human):
    # completar
    raise NotImplementedError


def has_pick(human):
    # completar
    raise NotImplementedError


def has_treasure(human):
    # completar
    raise NotImplementedError


def compute_damage(human):
    # completar
    raise NotImplementedError
